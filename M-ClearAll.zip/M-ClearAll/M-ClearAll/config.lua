Config = {}

Config.ClearAll = {
    Ace = "furiousfoxgg.clearall",
    Command = "clearall",
    Discord = {
        Webhook = "",
        ServerName = "FuriousFoxGG Development",
    }
}